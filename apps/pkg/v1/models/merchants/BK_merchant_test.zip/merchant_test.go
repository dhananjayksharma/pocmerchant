package merchants

import (
	"dkgosql-merchant-service-v3/pkg/v1/models/mocks"
	"dkgosql-merchant-service-v3/pkg/v1/models/response"

	"fmt"
	"testing"

	"github.com/gin-gonic/gin"
	"github.com/go-playground/assert/v2"
	"github.com/golang/mock/gomock"
)

func TestGetMerchantList(t *testing.T) {
	gin.SetMode(gin.TestMode)
	var c *gin.Context
	emptyMerchant := []response.MerchantResponse{}
	merchantsList := []response.MerchantResponse{
		{
			Code: "1245df",
			Name: "Cisca",
		},
		{
			Code: "1245df",
			Name: "Cisca",
		},
	}

	tt := []struct {
		name      string
		merchants []response.MerchantResponse
		wantErr   error
		mockFunc  func(repo *mocks.MockMySQLDBStoreAccess)
	}{
		{
			name:      "merchant list found successfully",
			merchants: merchantsList,
			mockFunc: func(dbStore *mocks.MockMySQLDBStoreAccess) {
				dbStore.EXPECT().GetMerchantList(gomock.Any(), gomock.Any()).Return(merchantsList, nil)
			},
		},
		{
			name:      "merchant list not found",
			merchants: emptyMerchant,
			mockFunc: func(dbStore *mocks.MockMySQLDBStoreAccess) {
				dbStore.EXPECT().GetMerchantList(gomock.Any(), gomock.Any()).Return(emptyMerchant, nil)
			},
			wantErr: fmt.Errorf("merchant list not found"),
		},
	}

	for _, tc := range tt {
		t.Run(tc.name, func(t *testing.T) {
			ctrl := gomock.NewController(t)
			defer ctrl.Finish()
			dbStore := mocks.NewMockMySQLDBStoreAccess(ctrl)
			service := NewMerchantService(dbStore)
			tc.mockFunc(dbStore)
			data, err := service.List(c)
			if err != nil {
				assert.Equal(t, tc.wantErr.Error(), err.Error())
			} else {
				assert.Equal(t, data.Data, merchantsList)
			}
		})
	}
}
